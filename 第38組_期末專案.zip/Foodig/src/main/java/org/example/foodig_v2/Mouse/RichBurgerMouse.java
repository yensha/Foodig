package org.example.foodig_v2.Mouse;

public class RichBurgerMouse extends Mouse {
    public RichBurgerMouse() {
        super("黃金招財鼠來堡", 20, 1.0, false,"image/burgermouse.png",10000);
    }
}
