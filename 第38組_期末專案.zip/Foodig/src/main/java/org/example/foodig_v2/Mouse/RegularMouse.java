package org.example.foodig_v2.Mouse;

public class RegularMouse extends Mouse {

    public RegularMouse() {
        super("勞贖", 10, 1.0, false, "image/mouse1.png",0);
    }


}
