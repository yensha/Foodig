package org.example.foodig_v2.Mouse;

public class ComputerMouse extends Mouse {

    public ComputerMouse() {
        super("滑鼠", 16, 1.0, false, "image/mouse3.png", 5000);
    }


}
