package org.example.foodig_v2.Mouse;

public class FlatMouse extends Mouse {
    public FlatMouse() {
        super("鼠餅", 12, 1.0, false, "image/mouse2.png", 2000);
    }
}
